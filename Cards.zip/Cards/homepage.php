<?php
require "filter.php";

$text = xss_clean($_GET['text'].'.png') ;
?>

<!DOCTYPE html>
<html>
<head>
    <title>بطاقة المعايدة</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.1.6/css/uikit-rtl.css" />
    <link rel="stylesheet" href="css/style.css" />


</head>
<body>
<center>
    <div class="clr"></div>
    <a href="homepage.php"><img src="img/logo1.png" style="width:100px;margin:20px;" /></a>
    <div class="clr"></div>
    <img src="img/<?= $text ?>" style="width:500px;" />
</center>
</body>
<script>
    // Trigger download using JavaScript after the HTML content has loaded
    document.addEventListener('DOMContentLoaded', function () {
        var link = document.createElement('a');
        link.href = 'img/<?= $text ?>';
        link.download = '<?= $text ?>';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
</script>
</html>
