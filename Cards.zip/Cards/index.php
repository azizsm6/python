
<!DOCTYPE html>
<html>
<head>
    <title>بطاقة المعايدة</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.1.6/css/uikit-rtl.css" />
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
<center>
</center>
<div id="HomePage">
    <div>
        <center>
            <div class="clr"></div>

            <a href="https://tilad.com.sa/"><img src="img/logo1.png" style="width:200px;" /></a>            <div class="clr"></div> 
            <h2 class="aid-text">
اهلاً بكم, موظفينا الأعزاء  
<br>
                تقدم لكم هذه الصفحة خدمة بطاقة المعايدة بمناسبة رمضان 
                <br>
                وكل عام وأنتم بالف خير  
                <br>
                Welcome, our dear employees
                <br>
                This page offers you the service of a Ramadan greeting card <br> wishing you all the best every year
                <br><br>
                يمكنك كتابة الإسم أسفله لإنشاء بطاقة خاصة بالإسم المدخل
                <br>
                You can write the name below to create a card with the entered name
                </h2>
            <div class="clr"></div><br>
            <form action="download.php" method="post">
                <fieldset class="uk-fieldset">
                    <div class="uk-margin">
                        <input class="uk-input inpu" type="text" name="fullname" placeholder="أدخل الإسم هنا / Enter the name here">
                    </div>
                    <div class="uk-margin">
                        <button type="submit" name="Send" class="uk-button button">عرض البطاقة / Generate the card </button>
                    </div>
                </fieldset>
            </form>
            <div class="clr"></div><br>

        </center>
    </div>
    <footer>

    </footer>
</div>
</body>
</html>
