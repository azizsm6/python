<?php
include "word2uni.php";
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Load the existing image
$existingImage = imagecreatefrompng(__DIR__.'/img/image.png');
require "filter.php";

function isEnglish($text) {
    // Check if the text contains only English characters
    return preg_match('/^[a-zA-Z\s]+$/', $text);
}
$_POST['fullname'] = xss_clean($_POST['fullname']);
// Add Arabic text to the image
if (isEnglish($_POST['fullname'])) {
    $text = $_POST['fullname'];
    $font = __DIR__.'/arial.ttf'; // Change this to a font that supports Arabic
} else {
    $text = text2uni($_POST['fullname']);
    $font = __DIR__.'/GE SS Two Medium.otf'; // Change this to a font that supports Arabic
}
$textColor = imagecolorallocate($existingImage, 0, 102, 112); // White color

// Get image dimensions
$imageWidth = imagesx($existingImage);
$imageHeight = imagesy($existingImage);
$fontSize = 45;

// Create a new text box
$textBoundingBox = imagettfbbox($fontSize, 0, $font, $text);
$textWidth = $textBoundingBox[2] - $textBoundingBox[0];
$textHeight = $textBoundingBox[1] - $textBoundingBox[7];

// Calculate text position (bottom center)
$textX = ($imageWidth - $textWidth) / 2;
$textY = $imageHeight - 237; // Adjust 10 pixels from the bottom

// Use the 'bidi' extension for proper RTL rendering
if (extension_loaded('bidi')) {
    $text = bidi($text, 'R');
}

imagettftext($existingImage, $fontSize, 0, $textX, $textY, $textColor, $font, $text);

// Save the modified image to a file (optional)
$imageFilePath = __DIR__.'/img/'.$_POST['fullname'].'.png';
imagepng($existingImage, $imageFilePath);

// Free up memory
imagedestroy($existingImage);

echo "<script>location.href='homepage.php?text=$_POST[fullname]'</script>";
?>